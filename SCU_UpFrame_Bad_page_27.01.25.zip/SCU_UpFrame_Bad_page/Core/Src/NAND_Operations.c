/*
 * NAND_Operations.c
 *
 *  Created on: Nov 14, 2024
 *      Author: AEM
 */

#include "main.h"
#include <stdio.h>
#include <string.h>
#include"ATP_Mode.h"
#include"NAND_Operations.h"


// Global NAND configuration and data buffers
NAND_IDTypeDef nand_details;
NAND_AddressTypeDef nand_address = {0, 0, 0};
NAND_Die_Status nand_die_status[2];  // Two entries for Die 1 and Die 2
char nand_stop_read_CMD[3]={0};
uint8_t read_data[8192] = {0};
uint8_t NAND_data[8192] = {0};
uint8_t SRAM_Data[8192] = {0};
uint8_t spare_buffer[448] = {0};
//uint8_t nand_block_status[2][4096] = {0};
uint32_t page_read = 0;
uint32_t block_read = 0;
uint32_t plane_read = 0;
uint8_t nand_update = 0;
uint8_t nand_cyclic_run = 0;
uint16_t bad_block_check_counter = 0;
static const char *NdStatus  = "NAND erased successfully!\n";
static const char *NdErStatus= "Error erasing NAND.\n";
/*
 * functions prototype
 */
void nand_erase(void);
void NAND_operation(void);
void get_Good_NAND_block();
void handle_bad_block(void);
void get_NAND_block_status();
int count_set_bits(uint8_t byte);
uint8_t get_NAND_stored_data(uint16_t requested_blocks);
//uint8_t data_fetch(uint16_t start_block, uint16_t end_block, uint8_t current_die);
int calculate_hamming_distance(const uint8_t *str1, const uint8_t *str2, size_t length);
void set_NAND_block_status(uint16_t page, uint16_t block, uint16_t plane, uint8_t block_state);
uint8_t data_fetch_1(uint16_t start_block, uint16_t end_block, uint8_t current_die ,uint16_t user_req);
uint8_t data_fetch_2(uint16_t start_block, uint16_t end_block, uint8_t current_die ,uint8_t user_req);
uint8_t data_fetch_3(uint16_t start_block, uint16_t end_block, uint8_t current_die ,uint8_t user_req);
uint8_t data_fetch_4(uint16_t start_block, uint16_t end_block, uint8_t current_die ,uint8_t user_req);

/**
 * @brief Performs NAND operations like writing, reading, and checking block status.
 * This function writes data to NAND, reads it back to verify, checks and updates
 * block status based on the comparison result.
 */
void NAND_operation(void)
{

	HAL_GPIO_TogglePin(GPIOE, LED5_Pin);  // Toggle status LED
	// Move to the next block if all pages in the current block have been written
	if (nand_address.Page > 127)
	{
		get_Good_NAND_block();
		nand_address.Page = 0;
		NAND_DieSwitch(NAND_Die);
		HAL_NAND_Erase_Block(&hnand1, &nand_address);
		HAL_Delay(20);
		NAND_DieSwitch(NAND_DieDisable);
	}

	memset(read_data, 0, 8192);
	memset(NAND_data, 0, 8192);

	// Prepare data for NAND write
	get_NAND_data(NAND_data);

	if(NAND_data[0] && NAND_data[20] == 0xE0)
	{
		// Write data to NAND flash
		NAND_DieSwitch(NAND_Die);
		nand_address.Block++;
		HAL_NAND_Write_Page_8b(&hnand1, &nand_address, NAND_data, 1);
		// Read data back from NAND flash for verification
		HAL_NAND_Read_Page_8b(&hnand1, (const NAND_AddressTypeDef *) &nand_address, read_data, 1);
		nand_address.Block--;
		NAND_DieSwitch(NAND_DieDisable);// Disable Die
		return;
	}

	// Write data to NAND flash
	NAND_DieSwitch(NAND_Die);
	HAL_NAND_Write_Page_8b(&hnand1, &nand_address, NAND_data, 1);

	// Read data back from NAND flash for verification
	HAL_NAND_Read_Page_8b(&hnand1, (const NAND_AddressTypeDef *) &nand_address, read_data, 1);
	//	HAL_UART_Transmit(&huart5, read_data, sizeof(read_data),HAL_MAX_DELAY);
	//	HAL_Delay(20);
	NAND_DieSwitch(NAND_DieDisable);// Disable Die
	// Calculate bit difference between written and read data
	uint16_t bit_difference = calculate_hamming_distance(NAND_data, read_data, 8192);

	// Check if data read matches data written
	if (bit_difference <50) // Data matches
	{
		if (nand_address.Page == 0)
		{
			set_NAND_block_status(nand_address.Page, nand_address.Block, nand_address.Plane, Good_Block); // Mark block as good
		}
		nand_address.Page++;

	}
	else // Data mismatch - possible bad block
	{
		bad_block_check_counter = 0 ;
		handle_bad_block(); // Call function to handle the bad block scenario
		bad_block_check_counter = 0;
	}

	nand_update = 1;
	update_NAND_Die();
	update_NAND_addr();
	update_NAND_CyclicAddr();

}

/**
 * @brief Reads and updates the status of each block in NAND.
 * Sets the block status array based on whether the block is good (0xFF) or bad (0x00).
 */
void get_NAND_block_status()
{
	/*
	 * Enable First Die
	 */
	NAND_DieSwitch(1);
	for (uint16_t i = 0; i < 4096; i++)
	{
		nand_address.Block = i;
		HAL_NAND_Read_SpareArea_8b(&hnand1, &nand_address, spare_buffer, 1);
		//		nand_die_status[Die_1].nand_status.block_status[i]=(spare_buffer[0] == 0xFF) ? 1 : 0;
		nand_die_status[Die_1].block_status_bitmap[i / 32] |= (((spare_buffer[0] == 0xFF) ? 1 : 0) << (i % 32));
	}
	/*
	 * Enable second Die
	 */
	if(nand_address.Block >= 4095)
	{
		nand_address.Block=0;
		NAND_DieSwitch(2);
		for (uint16_t i = 0; i < 4096; i++)
		{
			nand_address.Block = i;
			HAL_NAND_Read_SpareArea_8b(&hnand1, &nand_address, spare_buffer, 1);
			//			nand_die_status[Die_2].nand_status.block_status[i]=(spare_buffer[0] == 0xFF) ? 1 : 0;
			nand_die_status[Die_2].block_status_bitmap[i / 32] |= (((spare_buffer[0] == 0xFF) ? 1 : 0) << (i % 32));
		}
	}
	for(uint16_t i = 0; i < 4096; i++)
	{
		for (uint16_t j = 0; j < 128; j++)
		{
			//		nand_die_status[Die_1].nand_status.page_status[i]= Good_Page;
			//		nand_die_status[Die_2].nand_status.page_status[i]= Good_Page;
			nand_die_status[Die_1].bad_page_map[i][j / 8]|=(Good_Page << (j % 8));
			nand_die_status[Die_2].bad_page_map[i][j / 8]|=(Good_Page << (j % 8));
		}
	}
}

/**
 * @brief Sets the status of a NAND block by updating its spare area.
 * @param page The page number within the block.
 * @param block The block number to update.
 * @param plane The NAND plane number.
 * @param block_state 1 for good block, 0 for bad block.
 */
void set_NAND_block_status(uint16_t page, uint16_t block, uint16_t plane, uint8_t block_state)
{
#if 1

	NAND_AddressTypeDef nand_address_block = {0, block, plane};
	NAND_DieSwitch(NAND_Die);

	// Read current spare area of the block
	HAL_NAND_Read_SpareArea_8b(&hnand1, &nand_address_block, spare_buffer, 1);

	// Update the spare buffer to mark block as good (0xFF) or bad (0x00)
	spare_buffer[0] = (block_state) ? 0xFF : 0x00;

	if (page > 0 && page <= MAX_PAGE) {
		if (NAND_Die == 1) {
			// Mark the page as bad in the bad page map for Die 1
			nand_die_status[Die_1].bad_page_map[block][page / 8] &= ~(1 << (page % 8)); // 0 = Bad Page
		} else if (NAND_Die == 2) {
			// Mark the page as bad in the bad page map for Die 2
			nand_die_status[Die_2].bad_page_map[block][page / 8] &= ~(1 << (page % 8)); // 0 = Bad Page
		}
	} else {
		if (NAND_Die == 1) {
			// Update block status in bitmap for Die 1
			if (block_state == 1) {
				nand_die_status[Die_1].block_status_bitmap[block / 32] |= (1 << (block % 32));// 1 = Good Block
			} else {
				nand_die_status[Die_1].block_status_bitmap[block / 32] &= ~(1 << (block % 32));// 0 = Bad Block
			}
		} else if (NAND_Die == 2) {
			// Update block status in bitmap for Die 2
			if (block_state == 1) {
				nand_die_status[Die_2].block_status_bitmap[block / 32] |= (1 << (block % 32));// 1 = Good Block
			} else {
				nand_die_status[Die_2].block_status_bitmap[block / 32] &= ~(1 << (block % 32));// 0 = Bad Block
			}
		}
	}

	// Write updated spare buffer back to the NAND
	HAL_NAND_Write_SpareArea_8b(&hnand1, &nand_address_block, spare_buffer, 1);
	NAND_DieSwitch(NAND_DieDisable);

#endif
#if 0
	NAND_AddressTypeDef nand_address_block = {0, block, plane};

	NAND_DieSwitch(NAND_Die);
	HAL_NAND_Read_SpareArea_8b(&hnand1, &nand_address_block, spare_buffer, 1);

	spare_buffer[0] = (block_state) ? 0xFF : 0x00;  // Set good (0xFF) or bad (0x00)
	if(NAND_Die ==1)
		nand_block_status[Die_1][block] = block_state;          // Update block status array
	if(NAND_Die ==2)
		nand_block_status[Die_2][block] = block_state;          // Update block status array
	HAL_NAND_Write_SpareArea_8b(&hnand1, &nand_address_block, spare_buffer, 1);
	NAND_DieSwitch(NAND_DieDisable);
#endif

}

/**
 * @brief Counts the number of set bits (1s) in a byte.
 * @param byte The byte to analyze.
 * @return The number of set bits in the byte.
 */
int count_set_bits(uint8_t byte)
{
	int count = 0;
	while (byte)
	{
		count += byte & 1;
		byte >>= 1;
	}
	return count;
}

/**
 * @brief Calculates the Hamming distance (bit differences) between two 8192-byte strings.
 * @param str1 Pointer to the first 8192-byte string.
 * @param str2 Pointer to the second 8192-byte string.
 * @param length Length of the strings to compare (8192 bytes).
 * @return The number of differing bits between the two strings.
 */
int calculate_hamming_distance(const uint8_t *str1, const uint8_t *str2, size_t length)
{
	int differing_bits = 0;
	for (size_t i = 0; i < length; i++)
	{
		differing_bits += count_set_bits(str1[i] ^ str2[i]);  // XOR and count set bits in result
	}
	return differing_bits;
}

/**
 * @brief Handles bad block processing in NAND by erasing and relocating data.
 * If data verification fails, the function marks the block as bad, and attempts to write data
 * to the next available block.
 */
void handle_bad_block(void)
{
#if 1 /* testing code for handle page data */

	//		nand_address.Page = 0;
	NAND_DieSwitch(NAND_Die);
	//	if(nand_address.Page == 0)
	//	{
	//		HAL_NAND_Erase_Block(&hnand1, &nand_address);
	//	}
	/*
	 * else store page in a uint32 variable
	 */
	//	HAL_Delay(100);
	if(bad_block_check_counter++ > 4094 )
	{
		return ;
	}

	if(nand_address.Page == 0){

		HAL_NAND_Erase_Block(&hnand1, &nand_address);
		HAL_Delay(20);
		// Attempt to rewrite data after erasing the block
		HAL_NAND_Write_Page_8b(&hnand1, &nand_address, NAND_data, 1);
		HAL_NAND_Read_Page_8b(&hnand1, (const NAND_AddressTypeDef *)&nand_address, read_data, 1);

		// Verify written data again
		if (calculate_hamming_distance(NAND_data, read_data, 8192) < 50) // Data matches
		{

			set_NAND_block_status(nand_address.Page, nand_address.Block, nand_address.Plane, Good_Block);

			nand_address.Page++;
			return ;
		}
		else // Mark block as bad and attempt to move data
		{
			set_NAND_block_status(nand_address.Page, nand_address.Block, nand_address.Plane, Bad_Block); // Mark as bad
			nand_address.Page = 0;
			get_Good_NAND_block();
			handle_bad_block();
			HAL_Delay(10); /*** need to optimization **/
		}
	}
	else /****************need to inspect*******************  if (page > 0) */
	{
		// Mark as Good but the page status is bad
		set_NAND_block_status(nand_address.Page, nand_address.Block, nand_address.Plane, Good_Block);
		nand_address.Page = 0;
		get_Good_NAND_block(); // check block status if bad it will increase the block till the good block not found.
		handle_bad_block();
		HAL_Delay(10); // check and optimize this delay
	}
	//	 HAL_GPIO_WritePin(NAND_CE_2_GPIO_Port, NAND_CE_2_Pin, GPIO_PIN_SET);
	NAND_DieSwitch(NAND_DieDisable);

#endif

#if 0
	nand_address.Page = 0;
	NAND_DieSwitch(NAND_Die);
	if(nand_address.Page == 0)
	{
		HAL_NAND_Erase_Block(&hnand1, &nand_address);
	}
	/*
	 * else store page in a uint32 variable
	 */
	HAL_Delay(100);
	if(bad_block_check_counter++ > 4094 )
	{
		return ;
	}
	// Attempt to rewrite data after erasing the block
	HAL_NAND_Write_Page_8b(&hnand1, &nand_address, NAND_data, 1);
	HAL_NAND_Read_Page_8b(&hnand1, (const NAND_AddressTypeDef *)&nand_address, read_data, 1);

	// Verify written data again
	if (calculate_hamming_distance(NAND_data, read_data, 8192) < 50) // Data matches
	{

		set_NAND_block_status(nand_address.Page, nand_address.Block, nand_address.Plane, Good_Block);

		nand_address.Page++;
	}
	else // Mark block as bad and attempt to move data
	{
		set_NAND_block_status(nand_address.Page, nand_address.Block, nand_address.Plane, Bad_Block); // Mark as bad
		nand_address.Page = 0;
		get_Good_NAND_block();
		handle_bad_block();
		HAL_Delay(10);
	}
	//	 HAL_GPIO_WritePin(NAND_CE_2_GPIO_Port, NAND_CE_2_Pin, GPIO_PIN_SET);
	NAND_DieSwitch(NAND_DieDisable);

#endif
}

void get_Good_NAND_block()
{

	if(NAND_Die == 2){
		while(nand_address.Block <= 4094 && ((((nand_die_status[Die_2].block_status_bitmap[(nand_address.Block+1)/32])>>((nand_address.Block+1) % 32))&0x1)^0x1))
		{
			nand_address.Block++;
			// Handle block wrapping around in case of overflow
			if (nand_address.Block > MAX_BLOCK)
			{
				nand_address.Block = 0;
				/******** Enable First Die and update the cyclic_run**************/
				NAND_Die = 1;
				Die_count =Die_1;
				nand_cyclic_run = 1;
			}
		}
	}
	else  //if(NAND_Die == 1)
	{
		while(nand_address.Block <= 4094 && ((((nand_die_status[Die_1].block_status_bitmap[(nand_address.Block+1)/32])>>((nand_address.Block+1) % 32))&0x1)^0x1))
		{
			nand_address.Block++;
			// Handle block wrapping around in case of overflow
			if (nand_address.Block > MAX_BLOCK)
			{
				nand_address.Block = 0;
				//				nand_cyclic_run = 1;
				/******** Enable Second Die **************/
				NAND_Die = 2;
				Die_count =Die_2;
			}
		}
	}
	nand_address.Block++;
	if (nand_address.Block > MAX_BLOCK && NAND_Die == 2)
	{
		nand_address.Block = 0;
		/******** Enable First Die **************/
		NAND_Die = 1;
		Die_count =Die_1;
		nand_cyclic_run = 1;
	}
	else if(nand_address.Block > MAX_BLOCK)
	{
		nand_address.Block = 0;
		/******** Enable Second Die **************/
		NAND_Die = 2;
		Die_count =Die_2;
	}

}

#if 1
uint8_t data_fetch(uint16_t start_block, uint16_t end_block, uint8_t current_die ,uint16_t user_req)  {
	NAND_AddressTypeDef nand_read_address;
	uint8_t die_switch_flag = 0;
	bool bit_store = false;
	while (start_block != (end_block+1) || die_switch_flag == 0) {
		uint16_t actual_block = start_block % MAX_BLOCKS_PER_DIE;
		//		uint8_t die = (start_block / MAX_BLOCKS_PER_DIE)+1;
		uint8_t die = 0;

		if(nand_cyclic_run == 1)
		{
			if(user_req > end_block)
			{

				if(actual_block >= 0 && start_block >= 4096)
				{
					if(current_die!=2)
					{
						die=2;
						NAND_DieSwitch(2);
					}
					else if(current_die!=1)
					{
						die=1;
						NAND_DieSwitch(1);
					}
				}
				else if((actual_block == 0) && (start_block == 0))
				{
					die=current_die;
					NAND_DieSwitch(current_die);
				}
				else if(user_req > MAX_BLOCKS_PER_DIE)
				{
					die=current_die;
					NAND_DieSwitch(current_die);
				}
			}
			else if(user_req <= end_block)
			{
				die=current_die;
				NAND_DieSwitch(current_die);
			}
			else
			{
				//				if((actual_block == 0) && (start_block == 0))
				//				{
				//					NAND_DieSwitch(current_die);
				//				}
				//
				//				else if((actual_block && start_block) != 0)
				//				{
				//					if(current_die!=2)
				//					{
				//						NAND_DieSwitch(2);
				//					}
				//					else if(current_die!=1)
				//					{
				//						NAND_DieSwitch(1);
				//					}
				//				}
			}

		}

		if(user_req > end_block)
		{
			if((actual_block >= 0) && (start_block < 4096))
			{
				die=current_die;
				NAND_DieSwitch(current_die);
			}
			else if((start_block < 8191) && (start_block > 4096))
			{
				if(current_die!=2)
				{
					die=2;
					NAND_DieSwitch(2);
				}
				else if(current_die!=1)
				{
					die=1;
					NAND_DieSwitch(1);
				}
			}
			else
			{
				die=current_die;
				NAND_DieSwitch(current_die);
			}
		}
		else
		{
			die=current_die;
			NAND_DieSwitch(current_die);
		}


		for (int page = 0; page <= MAX_PAGE; page++) {
			nand_read_address.Block = actual_block;
			nand_read_address.Page = page;
			nand_read_address.Plane = 0;
			bit_store = false;
#if 0
			bit_store = (nand_die_status[die-1].block_status_bitmap[(nand_read_address.Block)/32]) >> ((nand_read_address.Block) % 32);
			bit_store &= 0x1;
			bit_store ^= 0x1;
#endif

			// Handle bad blocks and pages
			while((((nand_die_status[die-1].block_status_bitmap[(nand_read_address.Block) / 32]) >> ((nand_read_address.Block) % 32))&0x1)^0x1)
			{
				bit_store = true;
				break;
			}
			if(bit_store == true){
				bit_store = false;
				break;
			}
			if((nand_die_status[die-1].bad_page_map[nand_read_address.Block][(nand_read_address.Page) / 8] >> ((nand_read_address.Page) % 8)&0x1)^0x1)
			{
				bit_store = true;
				break;
			}
			if(bit_store == true){
				bit_store = false;
				break;
			}

			if (nand_stop_read_CMD[1] == '*') {
				return 0;
			}
			// Read data from the page
			HAL_NAND_Read_Page_8b(&hnand1, &nand_read_address, read_data, 1);

			// Send data over UART
			for (uint16_t cnt = 0; cnt < 8192; cnt++) {
				UART5->TDR = read_data[cnt];
				HAL_Delay(1);
				if (nand_stop_read_CMD[1] == '*') {
					NAND_DieSwitch(DISABLE);
					return 0;
				}
			}
		}

		// Increment to the next block
		start_block = (start_block + 1) % TOTAL_BLOCKS;

		if (start_block == (end_block+1)) {
			die_switch_flag = 1; // Indicate that we've completed the read
		}
	}
	return 0;
}

uint8_t get_NAND_stored_data(uint16_t requested_blocks) {
	uint16_t start_block, end_block = nand_address.Block;
	uint8_t current_die = Die_count+1;
	uint16_t request_blk = requested_blocks;
	if (requested_blocks > TOTAL_BLOCKS) {
		requested_blocks = TOTAL_BLOCKS;
	}

	// Calculate start block based on cyclic or non-cyclic mode
	if (nand_cyclic_run) {
		if (end_block < requested_blocks)
		{
			start_block = TOTAL_BLOCKS - (requested_blocks - end_block);
		}
		else
		{
			start_block = end_block - requested_blocks;
		}

	} else {
		if (end_block >= requested_blocks) {
			start_block = end_block - requested_blocks;
		} else {
			start_block = (TOTAL_BLOCKS - (requested_blocks - end_block)) % TOTAL_BLOCKS;
		}
	}

	//	 Fetch data
	data_fetch(start_block, end_block, current_die , request_blk);

	if (nand_stop_read_CMD[1] == '*') {
		memset(nand_stop_read_CMD, 0, 3);
		NAND_DieSwitch(DISABLE);
		return 0;
	}
	NAND_DieSwitch(DISABLE);
	return 0;
}
#endif

#if 0
uint8_t data_fetch(uint16_t start_block, uint16_t end_block, uint8_t current_die)
{
	NAND_AddressTypeDef nand_read_address;
	uint8_t die_switch_flag = 0;

	while (start_block != end_block || die_switch_flag == 0) {
		// Calculate block and die
		uint16_t actual_block = start_block % MAX_BLOCKS_PER_DIE;
		uint8_t die = (start_block / MAX_BLOCKS_PER_DIE)+1; // need to check this condition

		// Switch to the correct die
		if (current_die != die) {
			NAND_DieSwitch(die);
			current_die = die;
		}

		for (int page = 0; page <= MAX_PAGE; page++) {
			nand_read_address.Block = actual_block;
			nand_read_address.Page = page;
			nand_read_address.Plane = 0;

			// Handle bad blocks
			if(die == 2)
			{
				while((((nand_die_status[Die_2].block_status_bitmap[(nand_read_address.Block)/32])>>((nand_read_address.Block) % 32))&0x1)^0x1)
				{
					nand_read_address.Block++;
				}

			}
			else  //if(NAND_Die == 1)
			{
				while((((nand_die_status[Die_1].block_status_bitmap[(nand_read_address.Block)/32])>>((nand_read_address.Block) % 32))&0x1)^0x1)
				{
					nand_read_address.Block++;
				}

			}

			if(die == 2)
			{

				if((nand_die_status[Die_2].bad_page_map[nand_read_address.Block][(nand_read_address.Page) / 8] >> ((nand_read_address.Page) % 8)&0x1)^0x1)
				{
					nand_read_address.Block++;
					nand_read_address.Page=0;
					page=0;
					//					break;
				}
			}
			else
			{

				if((nand_die_status[Die_1].bad_page_map[nand_read_address.Block][(nand_read_address.Page) / 8] >> ((nand_read_address.Page) % 8)&0x1)^0x1)
				{
					nand_read_address.Block++;
					nand_read_address.Page=0;
					page=0;
					//					break;
				}
			}
			if(nand_stop_read_CMD[1]=='*')
				return 0;
			// Read data from the page
			HAL_NAND_Read_Page_8b(&hnand1, &nand_read_address, read_data, 1);

			// Send data over UART
			//			HAL_UART_Transmit(&huart5, read_data, sizeof(read_data), HAL_MAX_DELAY);
			for(uint8_t cnt = 0 ; cnt <= 8192 ; cnt++){
				UART5->TDR = read_data[cnt];
				HAL_Delay(1);
				if(nand_stop_read_CMD[1]=='*'){
					return 0;
				}
			}


		}
		// Increment to the next block
		start_block = (start_block + 1) % TOTAL_BLOCKS;
		if (start_block == end_block) {
			die_switch_flag = 1; // Indicate that we've finished
		}
	}
	return 0;
}

uint8_t get_NAND_stored_data()
{
	uint16_t end_block = nand_address.Block;
	uint16_t start_block;
	uint16_t requested_blocks = 2;

	// Calculate the start block based on the number of requested blocks
	if (requested_blocks >= TOTAL_BLOCKS) {
		start_block = (end_block + 1) % TOTAL_BLOCKS; // Read the entire memory
	} else {
		if (end_block >= requested_blocks) {
			start_block = end_block - requested_blocks;
		} else {
			start_block = TOTAL_BLOCKS - (requested_blocks - end_block);
		}
	}

	// Fetch the data
	data_fetch(start_block, end_block, 1);

	if(nand_stop_read_CMD[1]=='*'){
		memset(nand_stop_read_CMD,0,3);
		return 0;
	}
	return 0;
}
#endif

void nand_erase()
{
	uint8_t Nandcnt = 0;
	nand_address.Block=0;
	NAND_DieSwitch(1);
	while (1){

		if(HAL_NAND_Erase_Block(&hnand1, &nand_address) == HAL_OK){
			HAL_Delay(10);
			nand_address.Block++;
			if (Nandcnt!=1 && nand_address.Block > MAX_BLOCK)
			{
				Nandcnt=1;
				NAND_DieSwitch(2);
				nand_address.Block = 0;
			}
			if (Nandcnt==1 && nand_address.Block > MAX_BLOCK)
			{
				NAND_DieSwitch(DISABLE);
				// Clear the SRAM location
				memset(&SRAM_clean,0x00,8192);
				HAL_SRAM_Write_8b(&hsram1, (uint32_t *)sramAddr_base_addr, SRAM_clean, 8192);
				HAL_Delay(100);
				Die_count = 0;
				size_counter = 0;
				nand_cyclic_run = 0;
				update_NAND_Die();
				update_NAND_CyclicAddr();
				Init_NAND_addr();
				HAL_SRAM_Write_8b(&hsram1, (uint32_t *)0x6000000E, (uint8_t *)&size_counter, sizeof(size_counter));
				HAL_UART_Transmit(&huart5, (uint8_t *)NdStatus, strlen("NAND erased successfully!\n"),HAL_MAX_DELAY);
				break;
			}
		}
		else{

			HAL_UART_Transmit(&huart5, (uint8_t *)NdErStatus, strlen("Error erasing NAND.\n"),HAL_MAX_DELAY);
			break;
		}
	}
}

