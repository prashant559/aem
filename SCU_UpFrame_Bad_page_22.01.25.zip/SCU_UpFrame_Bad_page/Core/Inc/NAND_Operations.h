/*
 * NAND_Operations.h
 *
 *  Created on: Nov 14, 2024
 *      Author: AEM
 */

#ifndef INC_NAND_OPERATIONS_H_
#define INC_NAND_OPERATIONS_H_

/*
 *  @315 for 15 days
 *  @630 for 30 days
 */
#define BLOCK_OFFSET	 630
#define DIE_1 1
#define DIE_2 2

// External handles for NAND and UART
extern NAND_HandleTypeDef hnand1;
extern UART_HandleTypeDef huart4;
extern UART_HandleTypeDef huart5;

// Structure to represent NAND die status
typedef struct {
    uint32_t block_status_bitmap[MAX_BLOCK / 32 + 1]; // Bitmap for block status (0 = bad, 1 = good)
    uint16_t bad_page_map[MAX_BLOCK + 1][MAX_PAGE / 8 + 1]; // Map of bad pages in each block (1 bit per page)
} NAND_Die_Status;

#endif /* INC_NAND_OPERATIONS_H_ */
